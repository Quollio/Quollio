// Solution provided by Jackson Lewis
// Included headers
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
// disable warning messages
#pragma warning(disable:6031)
#pragma warning(disable:4244)
// namespace declaration
using namespace std;
// function declarations
void gameStart();
void upInput(char tiles[3][3]);
void downInput(char tiles[3][3]);
void leftInput(char tiles[3][3]);
void rightInput(char tiles[3][3]);
void scrambler(char randomizer[3][3]);
bool isSolved(char solution[3][3], int i, int j);
void colorPrinting(char colorCorrection[3][3], int i, int j);
// main
int main() {
	// function call to start the program
	gameStart();
	
	return 0;
}
// function definition
void gameStart() {
	// declare and initialize double pointer "puzzlePoint"
	char** puzzlePoint = NULL;
	int i(0), j(0);
	// allocate just enough memory for the pointer
	puzzlePoint = new(char* [3]);
	// variable declaration/initialization
	int keyboard(0);
	char temp = ' ';
	int currentColor = 7;
	// set the output color
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, currentColor);
	// declare and initialize 2D character array 'puzzle'
	char puzzle[3][3] = { {'1','2','3'}, {'4','5','6'}, {'7','8','*'} };
	for (int i = 0; i < 3; i++) {
		puzzlePoint[i] = new(char[3]);
	}
	// output the starting position of the array
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			// function call to change the color based on if a character is in the correct place or not
			colorPrinting(puzzle,i,j);
			if (puzzle[i][j] == '*') {
				// exception for the * character, keep that white
				SetConsoleTextAttribute(hConsole, currentColor);
			}
			cout << "  " << puzzle[i][j];
		}
		cout << endl;
	}
	// Prompt for randomizing the puzzle
	cout << "Press any button to scramble the puzzle: ";
	_getch();
	cout << endl;
	// function call for the randomizer
	scrambler(puzzle);
	// clear the screen
	system("CLS");
	// main loop that cancels if the user inputs 'X' on the keyboard
	while (keyboard != 'x' && keyboard != 'X') {
		// allocate memory for each section of the array
		for (int i = 0; i < 3; i++) {
			puzzlePoint[i] = new(char[3]);
		}
		// output the position of the array
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				// function call to check the positions and change color accordingly
				colorPrinting(puzzle, i, j);
				// exception for * character
				if (puzzle[i][j] == '*') {
					SetConsoleTextAttribute(hConsole, currentColor);
				}
				cout << "  " << puzzle[i][j];
			}
			cout << endl;
		}
		// sets the message to be white rather red or green
		SetConsoleTextAttribute(hConsole, currentColor);
		cout << "Green numbers are in the correct position. Red ones are not.\n";
		cout << "Use W,A,S,D, to move. Press X at any time to quit." << endl;
		// User can input X at any time to exit the program
		keyboard = _getch();
		// w input
		if (keyboard == 'w' || keyboard == 'W') {
			// function call to shift a piece upwards
			upInput(puzzle);
		}
		// a input
		if (keyboard == 'a' || keyboard == 'A') {
			// function call to shift a piece left
			leftInput(puzzle);
		}
		// s input
		if (keyboard == 's' || keyboard == 'S') {
			// function call to shift a piece downwards
			downInput(puzzle);
		}
		// d input
		if (keyboard == 'd' || keyboard == 'D') {
			// function call to shift a piece right
			rightInput(puzzle);
		}
		// refresh the screen
		system("CLS");
	}
	// deallocate memory
	for (int i = 0; i < 3; i++) {
		delete[] puzzlePoint[i];
	}
	delete[] puzzlePoint;
}
// function definition for moving a tile up
void upInput(char tiles[3][3]) {
	// temp variable declaration/initialization
	char temp = ' ';
	// check each row and column for the * character
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			// once it finds the * character
			if (tiles[i][j] == '*') {
				// prevents trying to move outside of the array
				if ((i + 1) > 2) {
					break;
				}
				// placeholder for the value being moved
				temp = tiles[i + 1][j];
				// value being moved now equals *
				tiles[i + 1][j] = tiles[i][j];
				// * now equals the original value
				tiles[i][j] = temp;
				// stops the loop, without this it loops twice for some reason, even with break
				i = 3;
			}
		}
	}
}
// function definition for moving a tile down
void downInput(char tiles[3][3]) {
	// temp variable declaration/initialization
	char temp = ' ';
	// check each place in the array for '*'
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (tiles[i][j] == '*') {
				// prevents movement outside of the array
				if (i - 1 < 0) {
					break;
				}
				// swap the values of * and the character above it
				temp = tiles[i - 1][j];
				tiles[i][j] = temp;
				tiles[i - 1][j] = '*';
				// break the loop
				break;
			}
		}
	}
}
// function definition for moving a tile to the left
void leftInput(char tiles[3][3]) {
	// temp variable declaration/initialization
	char temp = ' ';
	// scan array for * character
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (tiles[i][j] == '*') {
				// prevents movement outside the array
				if (j + 1 > 2) {
					break;
				}
				// swap the appropriate tiles
				temp = tiles[i][j + 1];
				tiles[i][j] = temp;
				tiles[i][j + 1] = '*';
				break;
			}
		}
	}
}
// function definition for moving a tile to the right
void rightInput(char tiles[3][3]) {
	// temp variable declaration/initialization
	char temp = ' ';
	// scan for *
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			if (tiles[i][j] == '*') {
				// prevent illegal movements
				if (j - 1 < 0) {
					break;
				}
				// swap appropriate tiles
				temp = tiles[i][j - 1];
				tiles[i][j] = temp;
				tiles[i][j - 1] = '*';
				break;
			}
		}
	}
}
// randomizer function
void scrambler(char randomizer[3][3]){
	// set the seed to the time so it's pseudorandom each time
	srand(time(NULL));
	// perform 1000 random legal transmutations of the board, each possible value calls a different function
	for (int i = 0; i <= 999; i++) {
		if (rand() % 4 == 0) {
			upInput(randomizer);
		}
		if (rand() % 4 == 1) {
			downInput(randomizer);
		}
		if (rand() % 4 == 2) {
			leftInput(randomizer);
		}
		if (rand() % 4 == 3) {
			rightInput(randomizer);
		}
	}
}
// function to determine if a piece is in the correct place
bool isSolved(char solution[3][3], int i, int j) {
	// set up and allocate memory for a second double pointer and 2D array to compare to the original
	char** completionPointer = NULL;
	completionPointer = new(char* [3]);
	char problemSolved[3][3] = { {'1','2','3'}, {'4','5','6'}, {'7','8','*'} };
	for (int i = 0; i < 3; i++) {
		completionPointer[i] = new(char[3]);
	}
	// variable declaration/initialization to false
	bool solved(0);
	// if the array at a given point is equal to the solution at the same point, output true
	if (problemSolved[i][j] == solution[i][j]) {
		solved = 1;
	}
	// return if it's true or false
	return solved;
	// deallocate memory
	for (int i = 0; i < 3; i++) {
		delete[] completionPointer[i];
	}
	delete[] completionPointer;
}
// function to change the color of a character in the array
void colorPrinting(char colorCorrection[3][3], int i, int j) {
	int currentColor = 7;
	// if isSolved function says the character is where it should be, make the color green
	if (isSolved(colorCorrection,i,j) == true) {
		currentColor = 10;
	}
	// otherwise make the color red
	else
		currentColor = 12;
	HANDLE hConsole;
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	// this part actually sets the color
	SetConsoleTextAttribute(hConsole, currentColor);
}